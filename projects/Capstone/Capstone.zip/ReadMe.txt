1. Place all the files in one folder and run capstone.ipynb
2. scikit,numpy,pandas are the libraries need to run capstone.ipyb
3. train.csv and test.csv are training and testing files respectively.
4. Once you run capstone.ipynb following files will be created, 
	a) Top  20 Imporatant features.fig
	b) Box plot of 20 features.fig
	c) BestRandomForestModel.csv
	d) BestRandomForestSensitivityModel.csv
5.BestRandomForestModel gives the predictions of the best model
6.BestRandomForestSensitivityModel gives the predicitons of the best model after sensitivity check.
6.Benchmark is the prediction of all zeros.
